<?php
    //contador
    $a=0;
    //ciclo donde muestra los numeros del 0 hasta que el contador sea 10
    do {
        echo "$a<br>";
        $a++;
    } while ($a <= 10);

?>